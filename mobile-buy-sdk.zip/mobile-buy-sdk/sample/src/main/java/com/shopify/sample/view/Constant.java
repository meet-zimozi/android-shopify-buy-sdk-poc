package com.shopify.sample.view;

public interface Constant {

  int PAGE_SIZE = 10;
  int THRESHOLD = 10;
}
